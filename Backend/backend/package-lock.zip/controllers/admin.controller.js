const db = require('../db');
const bcrypt = require('bcryptjs');

exports.createCompanyWithUser = (req, res) => {
  const { companyName, companyUrl, foundedDate, email, password } = req.body;

  if (!email || !password || !companyName || !companyUrl) {
    return res.status(400).json({ message: "Missing required fields" });
  }

  const hashed = bcrypt.hashSync(password, 10);

  //  ONLY type
  db.query(
    'INSERT INTO users (email, password, type) VALUES (?, ?, ?)',
    [email, hashed, 1], // 1 = company
    (err, userResult) => {
      if (err) {
        if (err.code === 'ER_DUP_ENTRY') {
          return res.status(400).json({ message: 'Email already exists' });
        }
        return res.status(500).json(err);
      }

      const userId = userResult.insertId;

      db.query(
        `
        INSERT INTO company (CompanyName, Company_URL, FoundedDate, user_id, role)
        VALUES (?, ?, ?, ?, 'admin')
        `,
        [companyName, companyUrl, foundedDate || null, userId],
        (err) => {
          if (err) return res.status(500).json(err);

          res.status(201).json({ message: 'Company created successfully' });
        }
      );
    }
  );
};


// ✅ GET ALL COMPANIES (ROOT ONLY)
exports.getAllCompanies = (req, res) => {
  db.query(
    `
    SELECT 
      c.CompanyID,
      c.CompanyName,
      c.Company_URL,
      c.FoundedDate,
      u.email
    FROM company c
    JOIN users u ON u.id = c.user_id
    `,
    (err, result) => {
      if (err) return res.status(500).json(err);
      res.json(result);
    }
  );
};

//professional course create
exports.createProfessionalCourse = (req, res) => {
  const { name } = req.body;

  if (!name) {
    return res.status(400).json({ message: 'Course name is required' });
  }

  db.query(
    'INSERT INTO professional_courses (name) VALUES (?)',
    [name],
    (err) => {
      if (err) {
        if (err.code === 'ER_DUP_ENTRY') {
          return res.status(400).json({ message: 'Course already exists' });
        }
        return res.status(500).json(err);
      }
      res.status(201).json({ message: 'Course created successfully' });
    }
  );
};


// GET OTP SETTINGS
exports.getOtpSettings = (req, res) => {
  db.query(
    "SELECT email_otp_enabled, phone_otp_enabled FROM system_settings WHERE id = 1",
    (err, result) => {
      if (err) return res.status(500).json(err);
      res.json(result[0]);
    }
  );
};

// UPDATE OTP SETTINGS
exports.updateOtpSettings = (req, res) => {
  const { emailEnabled, phoneEnabled } = req.body;

  db.query(
    "UPDATE system_settings SET email_otp_enabled = ?, phone_otp_enabled = ? WHERE id = 1",
    [emailEnabled, phoneEnabled],
    (err) => {
      if (err) return res.status(500).json(err);
      res.json({ message: "OTP settings updated successfully" });
    }
  );
};

// ================= CREATE COMPANY TYPE =================
exports.createCompanyType = (req, res) => {
  const { name } = req.body;

  if (!name) {
    return res.status(400).json({ message: 'Company type name is required' });
  }

  db.query(
    'INSERT INTO company_types (name) VALUES (?)',
    [name],
    (err) => {
      if (err) {
        if (err.code === 'ER_DUP_ENTRY') {
          return res.status(400).json({ message: 'Company type already exists' });
        }
        return res.status(500).json(err);
      }

      res.status(201).json({ message: 'Company type created successfully' });
    }
  );
};

// ================= GET ALL COMPANY TYPES (PUBLIC) =================
exports.getCompanyTypes = (req, res) => {
  db.query(
    'SELECT id, name FROM company_types ORDER BY name ASC',
    (err, result) => {
      if (err) return res.status(500).json(err);
      res.json(result);
    }
  );
};


// ================= CREATE UNIVERSITY =================
exports.createUniversity = (req, res) => {
  const { name } = req.body;

  if (!name) {
    return res.status(400).json({ message: "University name is required" });
  }

  const userId = req.user.id; // comes from auth middleware

  db.query(
    "INSERT INTO universities (name, created_by) VALUES (?, ?)",
    [name, userId],
    (err) => {
      if (err) {
        if (err.code === "ER_DUP_ENTRY") {
          return res.status(400).json({ message: "University already exists" });
        }
        return res.status(500).json(err);
      }

      res.status(201).json({ message: "University created successfully" });
    }
  );
};

// ================= GET ALL UNIVERSITIES =================
exports.getUniversities = (req, res) => {
  db.query(
    `
    SELECT 
      u.id,
      u.name,
      us.email AS created_by_email
    FROM universities u
    LEFT JOIN users us ON us.id = u.created_by
    ORDER BY u.name ASC
    `,
    (err, result) => {
      if (err) return res.status(500).json(err);
      res.json(result);
    }
  );
};

// ================= CREATE SCHOOL =================
exports.createSchool = (req, res) => {
  const { name } = req.body;

  if (!name) {
    return res.status(400).json({ message: "School name is required" });
  }

  db.query(
    "INSERT INTO schools (name) VALUES (?)",
    [name],
    (err) => {
      if (err) {
        if (err.code === "ER_DUP_ENTRY") {
          return res.status(400).json({ message: "School already exists" });
        }
        return res.status(500).json(err);
      }

      res.status(201).json({ message: "School created successfully" });
    }
  );
};

// ================= GET ALL SCHOOLS =================
exports.getSchools = (req, res) => {
  db.query(
    "SELECT id, name FROM schools ORDER BY name ASC",
    (err, result) => {
      if (err) return res.status(500).json(err);
      res.json(result);
    }
  );
};

//package create and offer create for compnay for buying package and creating 

exports.createPackage = (req, res) => {
  const {
    name,
    description,
    benefits,
    features,
    price,
    credit,
    job_limit,
    job_duration_days,
    package_duration_days
  } = req.body;

db.query(
    `INSERT INTO packages 
    (name, description, benefits, features, price, credit, job_limit, job_duration_days, package_duration_days)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [name, description, benefits, features, price, credit, job_limit, job_duration_days, package_duration_days],
    (err) => {
      if (err) return res.status(500).json(err);

      res.json({ message: "Package created successfully" });
    }
  );
};

// ================= GET ALL PACKAGES =================
exports.getPackages = (req, res) => {
  db.query("SELECT * FROM packages ORDER BY price ASC", (err, result) => {
    if (err) return res.status(500).json(err);
    res.json(result);
  });
};

// admin can get balance from company account

exports.getCompanyBalance = (req, res) => {
  const { companyId } = req.params;

  db.query(
    "SELECT balance FROM company WHERE CompanyID = ?",
    [companyId],
    (err, result) => {
      if (err) return res.status(500).json(err);
      res.json(result[0]);
    }
  );
};

//Add balance to company account to

exports.addBalance = (req, res) => {
  const { companyId, amount, paymentMethod } = req.body;

  if (!companyId || !amount || !paymentMethod) {
    return res.status(400).json({ message: "All fields required" });
  }

  // 1. Update company balance
  db.query(
    "UPDATE company SET balance = balance + ? WHERE CompanyID = ?",
    [amount, companyId],
    (err) => {
      if (err) return res.status(500).json(err);

      // 2. Insert transaction
      db.query(
        `INSERT INTO company_transactions (company_id, amount, payment_method)
         VALUES (?, ?, ?)`,
        [companyId, amount, paymentMethod],
        (err) => {
          if (err) return res.status(500).json(err);

          res.json({ message: "Balance added successfully" });
        }
      );
    }
  );
};




    









